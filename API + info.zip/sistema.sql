-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 15-Jul-2022 às 21:53
-- Versão do servidor: 8.0.27
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistema`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `campanhas`
--

DROP TABLE IF EXISTS `campanhas`;
CREATE TABLE IF NOT EXISTS `campanhas` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `idGrupoCidade` int NOT NULL,
  `descricao` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dataInicio` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dataFim` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ativa` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `campanhas`
--

INSERT INTO `campanhas` (`id`, `nome`, `idGrupoCidade`, `descricao`, `dataInicio`, `dataFim`, `ativa`, `created_at`, `updated_at`) VALUES
(1, 'Natal', 1, 'bom', '2022-07-21', '2022-08-24', 1, '2022-07-15 16:53:04', '2022-07-15 16:53:04'),
(2, 'Férias', 2, 'bom', '2022-07-01', '2022-07-31', 0, '2022-07-15 17:45:47', '2022-07-15 17:53:52'),
(3, 'Pascoa', 2, 'bonito', '2022-07-16', '2022-07-23', 1, '2022-07-15 18:10:12', '2022-07-15 18:10:12');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cidades`
--

DROP TABLE IF EXISTS `cidades`;
CREATE TABLE IF NOT EXISTS `cidades` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `estado` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `cidades`
--

INSERT INTO `cidades` (`id`, `nome`, `estado`, `created_at`, `updated_at`) VALUES
(1, 'São Paulo', 'São Paulo', '2022-07-15 16:51:32', '2022-07-15 16:51:32'),
(2, 'São Luis', 'Maranhão', '2022-07-15 16:51:57', '2022-07-15 16:51:57'),
(3, 'Brasília', 'Distrito Federal', '2022-07-15 22:25:55', '2022-07-15 22:25:55');

-- --------------------------------------------------------

--
-- Estrutura da tabela `descontos`
--

DROP TABLE IF EXISTS `descontos`;
CREATE TABLE IF NOT EXISTS `descontos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `idCampanha` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `descontos`
--

INSERT INTO `descontos` (`id`, `idCampanha`, `created_at`, `updated_at`) VALUES
(1, 3, NULL, '2022-07-15 18:12:32'),
(3, 1, '2022-07-15 18:13:06', '2022-07-15 18:13:06');

-- --------------------------------------------------------

--
-- Estrutura da tabela `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `grupo_cidades`
--

DROP TABLE IF EXISTS `grupo_cidades`;
CREATE TABLE IF NOT EXISTS `grupo_cidades` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `grupo_cidades`
--

INSERT INTO `grupo_cidades` (`id`, `nome`, `created_at`, `updated_at`) VALUES
(1, 'Grupo A', '2022-07-15 16:52:08', '2022-07-15 16:52:08'),
(2, 'Grupo B', '2022-07-15 16:52:18', '2022-07-15 16:52:18');

-- --------------------------------------------------------

--
-- Estrutura da tabela `id_desconto_id_produtos`
--

DROP TABLE IF EXISTS `id_desconto_id_produtos`;
CREATE TABLE IF NOT EXISTS `id_desconto_id_produtos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `idDesconto` int NOT NULL,
  `idProduto` int NOT NULL,
  `valor` double(8,2) NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `id_desconto_id_produtos`
--

INSERT INTO `id_desconto_id_produtos` (`id`, `idDesconto`, `idProduto`, `valor`, `tipo`, `created_at`, `updated_at`) VALUES
(6, 1, 2, 47.03, 'Porcentagem', '2022-07-15 20:09:01', '2022-07-15 20:22:37'),
(3, 1, 2, 69.00, 'Porcentagem', '2022-07-15 18:49:35', '2022-07-15 20:24:24'),
(4, 3, 2, 0.00, 'Porcentagem', '2022-07-15 18:49:47', '2022-07-15 18:49:47');

-- --------------------------------------------------------

--
-- Estrutura da tabela `id_grupo_id_cidades`
--

DROP TABLE IF EXISTS `id_grupo_id_cidades`;
CREATE TABLE IF NOT EXISTS `id_grupo_id_cidades` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `idGrupo` int NOT NULL,
  `idCidade` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `id_grupo_id_cidades`
--

INSERT INTO `id_grupo_id_cidades` (`id`, `idGrupo`, `idCidade`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2022-07-15 16:52:22', '2022-07-15 16:52:22'),
(2, 1, 2, '2022-07-15 16:52:28', '2022-07-15 16:52:28'),
(3, 2, 2, '2022-07-15 16:52:33', '2022-07-15 16:52:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_07_12_003848_create_produtos_table', 1),
(6, '2022_07_13_012007_create_cidades_table', 1),
(7, '2022_07_13_012418_create_grupo_cidades_table', 1),
(8, '2022_07_13_012454_create_campanhas_table', 1),
(9, '2022_07_13_012534_create_desconto_table', 1),
(10, '2022_07_14_022918_create_idgrupoidcidade_table', 1),
(11, '2022_07_15_125243_create_descontoidprodutoid_table', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantidade` int NOT NULL,
  `descricao` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `preco` double(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `quantidade`, `descricao`, `preco`, `created_at`, `updated_at`) VALUES
(1, 'bolo', 10, 'gostoso', 20.00, '2022-07-15 16:50:31', '2022-07-15 16:50:31'),
(2, 'pão', 1512, 'bom', 10.00, '2022-07-15 16:50:54', '2022-07-15 17:28:08'),
(3, 'Pastel', 50, 'bom', 2.48, '2022-07-15 21:51:16', '2022-07-15 21:51:16'),
(4, 'salgado', 24, 'bom', 1.99, '2022-07-15 21:53:33', '2022-07-15 21:53:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
